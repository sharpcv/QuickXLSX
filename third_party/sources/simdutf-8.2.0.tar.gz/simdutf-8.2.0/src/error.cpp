namespace simdutf {
// deliberately empty
}
